# Changelog

## v1.3.0

- Added 539 treasure spots and 40 rare entries from the CMaNGOS classic database (GPL-3.0):
  - New treasure types: Battered, Waterlogged, Dented, Mossy and Scarlet Footlockers, Giant Clams, Alliance and Horde Chests, Large Solid and Large Mithril Bound Chests, Buccaneer's Strongboxes
  - Missing spawn spots of chests already in the addon (mostly Mulgore)
  - New rares, including Sister Hatelash, Enforcer Emilgund, Boahn, Trigore the Lasher, Brainwashed Noble, Marisa du'Paige, Veyzhak the Cannibal, Zekkis, Geomancer Flintdagger, Digmaster Shovelphlange, Warleader Krazzilak, Old Cliff Jumper, Gish the Unmoving, Olm the Wise, Cursed Centaur, Accursed Slitherblade, Setis, Krellack and Grubthor
  - Extra spawn points for rares already in the addon
- Loot in tooltips for the new rares that have their own special drops: Brainwashed Noble, Marisa du'Paige, Trigore the Lasher, Boahn, Sister Hatelash and Digmaster Shovelphlange
- New pins are marked "unconfirmed" in the tooltip until they're checked in Forever
- Option: show/hide unconfirmed pins

## v1.2.0

- Share reminder: when you have 5 or more new finds, a chat message with a clickable link opens the export window (at most once an hour, can be turned off in the options)
- `/frares remind` shows the reminder right away

## v1.1.1

- Recorder no longer saves quest objects as treasures (objects that only give quest items, or show quest progress like 2/6)
- Quest items are no longer saved as loot
- Right-click a pin you recorded to delete it

## v1.1.0

- Added Redridge Mountains, Duskwood, Swamp of Sorrows, Blasted Lands and Desolace: now 309 rares and 948 treasure spots across 38 zones
- More accurate pin positions (zones are now lined up using treasure chests, which never move)
- Loot in tooltips: each rare's own special drops with drop chances (no random world drops), and treasure loot
- Items you loot from rares and treasures are saved and marked "seen in Forever"
- Classic drop chances shown as % (may differ in Forever)
- Options: show/hide loot, minimum quality, max lines
- `/frares export` now includes the loot you've seen

## v1.0.0

- First release.
- 274 rares and 661 treasure spots across 33 WoW Forever zones.
- Built-in recorder: saves new rares (target, mouseover, nameplate) and treasures (on loot) that the addon doesn't know yet.
- `/frares export` to share recorded pins.
- Left-click a pin for a waypoint (TomTom if installed), right-click to hide it.
