local ADDON, ns = ...
local PLUGIN = "RaresTreasuresForever"
local HandyNotes = LibStub and LibStub("AceAddon-3.0", true) and LibStub("AceAddon-3.0"):GetAddon("HandyNotes", true)
if not HandyNotes then
	-- Tell the player instead of failing silently
	SLASH_FOREVERRARES1 = "/frares"
	SlashCmdList.FOREVERRARES = function()
		print("|cffffd200Rares & Treasures Forever:|r HandyNotes is not loaded. Install/enable HandyNotes (a build with WoW Forever support).")
	end
	C_Timer.After(5, SlashCmdList.FOREVERRARES)
	return
end

local ICONS = {
	rare     = "Interface\\TargetingFrame\\UI-RaidTargetingIcon_8",
	treasure = "Interface\\Icons\\INV_Box_01",
}
local NEAR = 0.02 -- 2% of the map: closer than this counts as the same spot

local defaults = {
	showRares = true, showTreasures = true, showAlt = true, showRecorded = true, showUnconfirmed = true,
	minimap = true, scaleRare = 1.0, scaleTreasure = 0.8, alpha = 1.0,
	record = true, recordChat = true, remind = true, unshared = 0, lastReminder = 0,
	showLoot = true, lootQuality = 0, maxLoot = 15,
	hidden = {}, rec = {}, loot = {},
}
local db
local removeRecordedBooks -- defined below

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------
local function secret(v) return issecretvalue and issecretvalue(v) end

local function getXY(coord) return floor(coord / 10000) / 10000, (coord % 10000) / 10000 end
local function makeCoord(x, y) return floor(x * 10000 + 0.5) * 10000 + floor(y * 10000 + 0.5) end

local function isNear(c1, c2)
	local x1, y1 = getXY(c1)
	local x2, y2 = getXY(c2)
	return (x1 - x2) ^ 2 + (y1 - y2) ^ 2 <= NEAR ^ 2
end

local function guidInfo(guid)
	if not guid or secret(guid) then return end
	local kind, _, _, _, _, id = strsplit("-", guid)
	return kind, tonumber(id)
end

local function playerPos()
	local mapID = C_Map.GetBestMapForUnit("player")
	if not mapID then return end
	local pos = C_Map.GetPlayerMapPosition(mapID, "player")
	if not pos then return end
	local x, y = pos:GetXY()
	if not x or secret(x) or (x == 0 and y == 0) then return end
	return mapID, makeCoord(x, y)
end

---------------------------------------------------------------------------
-- Lookup: map -> coord -> { node, alt, recorded }
---------------------------------------------------------------------------
local lookup, known = {}, {} -- known[map]["rare:123"] = { coords... } for de-duplication

local function key(k, id) return k .. ":" .. id end

local function addEntry(mapID, coord, node, alt, recorded)
	local t = lookup[mapID] or {}
	lookup[mapID] = t
	while t[coord] do coord = coord + 1 end
	t[coord] = { node = node, alt = alt, recorded = recorded }
	local kn = known[mapID] or {}
	known[mapID] = kn
	local list = kn[key(node.k, node.id)] or {}
	kn[key(node.k, node.id)] = list
	list[#list + 1] = coord
end

local function rebuild()
	wipe(lookup); wipe(known)
	for mapID, nodes in pairs(ns.points) do
		for coord, node in pairs(nodes) do
			addEntry(mapID, coord, node, false, false)
			if node.alt then
				for _, c in ipairs(node.alt) do addEntry(mapID, c, node, true, false) end
			end
		end
	end
	if db.showRecorded then
		for mapID, nodes in pairs(db.rec) do
			for _, node in pairs(nodes) do
				for i, c in ipairs(node.pts) do addEntry(mapID, c, node, i > 1, true) end
			end
		end
	end
end

local function refresh() HandyNotes:SendMessage("HandyNotes_NotifyUpdate", PLUGIN) end

local function hideKey(node, uiMapID, coord)
	if node.k == "rare" then return key(node.k, node.id) end
	return "t:" .. uiMapID .. ":" .. coord
end

local function shouldShow(entry, minimap, uiMapID, coord)
	local node = entry.node
	if minimap and not db.minimap then return false end
	if entry.alt and node.k == "rare" and not db.showAlt then return false end
	if node.uv and not db.showUnconfirmed then return false end
	if node.k == "rare" and not db.showRares then return false end
	if node.k == "treasure" and not db.showTreasures then return false end
	if db.hidden[hideKey(node, uiMapID, coord)] then return false end
	return true
end

---------------------------------------------------------------------------
-- HandyNotes handler
---------------------------------------------------------------------------
local handler = {}

function handler:GetNodes2(uiMapID, minimap)
	local t = lookup[uiMapID]
	if not t then return function() end end
	local coord, entry
	return function()
		while true do
			coord, entry = next(t, coord)
			if not coord then return nil end
			if shouldShow(entry, minimap, uiMapID, coord) then
				local node = entry.node
				local scale = node.k == "rare" and db.scaleRare or db.scaleTreasure
				local alpha = db.alpha
				if entry.alt and node.k == "rare" then scale, alpha = scale * 0.7, alpha * 0.6 end
				return coord, nil, ICONS[node.k], scale, alpha
			end
		end
	end
end

-- Loot lines: items seen dropping in Forever first, then the rare's own specific drops by chance.
-- (Random world drops and shared trash are left out on purpose.)
local QUALITY_NAME = { [2] = "green", [3] = "blue", [4] = "purple" }
local function addLoot(tip, node)
	if not db.showLoot then return end
	local k = key(node.k, node.id)
	local data = ns.loot and ns.loot[k]
	local list, idx = {}, {}
	for itemID in pairs(db.loot[k] or {}) do
		idx[itemID] = #list + 1; list[#list + 1] = { itemID, 0, true }
	end
	for _, e in ipairs(data and data.i or {}) do
		local at = idx[e[1]]
		if at then
			list[at][2] = e[2]
		else
			idx[e[1]] = #list + 1; list[#list + 1] = { e[1], e[2], e[3] or false }
		end
	end
	local pools = data and data.p or {}
	if #list == 0 and #pools == 0 then
		if node.k == "rare" then
			tip:AddLine(" ")
			tip:AddLine("No known special drops yet.", 0.6, 0.6, 0.6)
			tip:AddLine("Kill and loot it to record what it drops.", 0.5, 0.5, 0.5)
		end
		return
	end

	tip:AddLine(" ")
	tip:AddLine("Loot:", 1, 0.82, 0)
	local shown, more, pending = 0, 0, 0
	for _, e in ipairs(list) do
		local itemID, chance, inForever = e[1], e[2], e[3]
		local name, _, quality, _, _, _, _, _, _, icon = C_Item.GetItemInfo(itemID)
		if not name then
			pending = pending + 1
		elseif (quality or 0) >= db.lootQuality or inForever then
			if shown < db.maxLoot then
				local r, g, b = C_Item.GetItemQualityColor(quality or 1)
				local right = inForever and "|cff66ff66seen in Forever|r" or (chance > 0 and (chance .. "%") or "")
				tip:AddDoubleLine("|T" .. (icon or 134400) .. ":0|t " .. name, right, r, g, b, 0.7, 0.7, 0.7)
				shown = shown + 1
			else
				more = more + 1
			end
		end
	end
	if more > 0 then tip:AddLine("...and " .. more .. " more (raise \"Max lines\" in options)", 0.6, 0.6, 0.6) end
	if pending > 0 then tip:AddLine("Loading " .. pending .. " items...", 0.5, 0.5, 0.5) end
	for _, pl in ipairs(pools) do
		local chance, lo, hi, q = pl[1], pl[2], pl[3], pl[4]
		local r, g, b = C_Item.GetItemQualityColor(q)
		local lvl = lo == hi and ("item level " .. lo) or ("item level " .. lo .. "-" .. hi)
		tip:AddDoubleLine("Random " .. (QUALITY_NAME[q] or "") .. " items, " .. lvl, chance .. "%", r, g, b, 0.7, 0.7, 0.7)
	end
	if not node.forever then
		tip:AddLine("Chances are from Classic and may differ in Forever.", 0.5, 0.5, 0.5, true)
	end
end

local tooltipPin -- { pin, uiMapID, coord } while our tooltip is open

function handler:OnEnter(uiMapID, coord)
	local entry = lookup[uiMapID] and lookup[uiMapID][coord]
	if not entry then return end
	tooltipPin = { self, uiMapID, coord }
	local node = entry.node
	local tip = GameTooltip
	tip:SetOwner(self, self:GetCenter() > UIParent:GetCenter() and "ANCHOR_LEFT" or "ANCHOR_RIGHT")
	tip:AddLine(node.n ~= "" and node.n or (node.k == "rare" and "Rare" or "Treasure"), 1, 0.82, 0)
	if node.k == "rare" then
		local kind = node.el and "Rare Elite" or "Rare"
		tip:AddLine(node.lv and (kind .. ", level " .. node.lv) or kind, 0.8, 0.8, 0.8)
		if entry.alt then tip:AddLine("Alternate spawn point", 0.6, 0.6, 1) end
	else
		tip:AddLine("Treasure", 0.8, 0.8, 0.8)
	end
	if node.uv then tip:AddLine("Unconfirmed: classic spawn point, not yet checked in Forever", 1, 0.6, 0.2, true) end
	if entry.recorded then tip:AddLine("Recorded by you", 0.4, 1, 0.4) end
	addLoot(tip, node)
	tip:AddLine(" ")
	tip:AddLine("Left-click: set waypoint", 0.5, 0.5, 0.5)
	if entry.recorded then
		tip:AddLine("Right-click: delete this recorded pin", 0.5, 0.5, 0.5)
	else
		tip:AddLine(node.k == "rare" and "Right-click: hide this rare" or "Right-click: hide this spot", 0.5, 0.5, 0.5)
	end
	tip:Show()
end

function handler:OnLeave() tooltipPin = nil; GameTooltip:Hide() end

local function setWaypoint(uiMapID, coord, title)
	local x, y = getXY(coord)
	if TomTom and TomTom.AddWaypoint then
		TomTom:AddWaypoint(uiMapID, x, y, { title = title, persistent = false, minimap = true, world = true })
	elseif C_Map.CanSetUserWaypointOnMap and C_Map.CanSetUserWaypointOnMap(uiMapID) then
		C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(uiMapID, x, y))
		if C_SuperTrack then C_SuperTrack.SetSuperTrackedUserWaypoint(true) end
	else
		print(("|cffffd200Rares & Treasures Forever:|r %s at %.1f, %.1f"):format(title, x * 100, y * 100))
	end
end

function handler:OnClick(button, down, uiMapID, coord)
	if down then return end
	local entry = lookup[uiMapID] and lookup[uiMapID][coord]
	if not entry then return end
	if button == "RightButton" and entry.recorded then
		-- delete a wrong recording (e.g. a quest object) instead of just hiding it
		local node = entry.node
		for i, c in ipairs(node.pts) do
			if c == coord or (i == 1 and isNear(c, coord)) then table.remove(node.pts, i); break end
		end
		if #node.pts == 0 and db.rec[uiMapID] then db.rec[uiMapID][key(node.k, node.id)] = nil end
		GameTooltip:Hide()
		rebuild(); refresh()
	elseif button == "RightButton" then
		db.hidden[hideKey(entry.node, uiMapID, coord)] = true
		GameTooltip:Hide()
		refresh()
	elseif button == "LeftButton" then
		setWaypoint(uiMapID, coord, entry.node.n)
	end
end

---------------------------------------------------------------------------
-- Clean-up: older versions recorded books/scrolls. Those belong to
-- "HandyNotes: Forever Books", so remove them (and their loot) on load.
---------------------------------------------------------------------------
local BOOK_WORDS = { "book", "tome", "scroll", "manual", "notes", "primer", "digest", "codex", "journal", "arcane secrets", "forever objects" }
local CONTAINER_WORDS = { "chest", "treasure", "cache", "coffer", "strongbox", "lockbox", "footlocker", "trunk" }
local function isBookName(name)
	local n = (name or ""):lower()
	-- a container is a treasure even if its name mentions a book ("Scholar's Chest", "Tome Cache")
	for _, w in ipairs(CONTAINER_WORDS) do
		if n:find(w, 1, true) then return false end
	end
	for _, w in ipairs(BOOK_WORDS) do
		if n:find(w, 1, true) then return true end
	end
	return false
end

removeRecordedBooks = function()
	local removed = 0
	for mapID, nodes in pairs(db.rec) do
		for k, node in pairs(nodes) do
			if node.k == "treasure" and isBookName(node.n) then
				nodes[k] = nil
				db.loot[k] = nil
				removed = removed + #node.pts
			end
		end
		if next(nodes) == nil then db.rec[mapID] = nil end
	end
	if removed > 0 then
		print(("|cffffd200Rares & Treasures Forever:|r removed %d recorded book pin(s). Use HandyNotes: Forever Books for books."):format(removed))
	end
end

---------------------------------------------------------------------------
-- In-game recorder
---------------------------------------------------------------------------
local function record(k, id, name, level, elite)
	if not db.record then return end
	local mapID, coord = playerPos()
	if not mapID then return end
	local kn = known[mapID] and known[mapID][key(k, id)]
	if kn then
		for _, c in ipairs(kn) do if isNear(c, coord) then return end end
	end
	db.rec[mapID] = db.rec[mapID] or {}
	local node = db.rec[mapID][key(k, id)]
	if not node then
		node = { k = k, id = id, n = name, lv = level, el = elite or nil, pts = {} }
		db.rec[mapID][key(k, id)] = node
	end
	node.pts[#node.pts + 1] = coord
	db.unshared = (db.unshared or 0) + 1
	if db.recordChat then
		local x, y = getXY(coord)
		print(("|cffffd200Rares & Treasures Forever:|r recorded new %s |cffffffff%s|r at %.1f, %.1f"):format(k, name, x * 100, y * 100))
	end
	rebuild(); refresh()
end

local function checkUnit(unit)
	if not UnitExists(unit) or UnitIsPlayer(unit) then return end
	local class = UnitClassification(unit)
	if secret(class) or (class ~= "rare" and class ~= "rareelite") then return end
	local kind, id = guidInfo(UnitGUID(unit))
	if not id or (kind ~= "Creature" and kind ~= "Vehicle") then return end
	local name, level = UnitName(unit), UnitLevel(unit)
	if secret(name) then return end
	if secret(level) or level == -1 then level = nil end
	record("rare", id, name or "Rare", level, class == "rareelite")
end

-- Treasures: remember the name of the last world object hovered, then record on loot.
local lastObject, lastObjectTime, lastObjectQuest
GameTooltip:HookScript("OnShow", function(tip)
	if tip:GetOwner() ~= UIParent or tip:GetUnit() then return end
	local line = _G["GameTooltipTextLeft1"]
	local text = line and line:GetText()
	if not text or secret(text) then return end
	lastObject, lastObjectTime, lastObjectQuest = text, GetTime(), false
	for i = 2, tip:NumLines() do
		local l = _G["GameTooltipTextLeft" .. i]
		local t = l and l:GetText()
		if t and not secret(t) and t:find("%d+/%d+") then lastObjectQuest = true; break end
	end
end)

-- Books/scrolls are left out on purpose: "HandyNotes: Forever Books" already covers the librarian's books.
local TREASURE_WORDS = CONTAINER_WORDS
local knownChestIDs = {}
for _, nodes in pairs(ns.points) do
	for _, node in pairs(nodes) do
		if node.k == "treasure" then knownChestIDs[node.id] = true end
	end
end

local function looksLikeTreasure(id, name)
	if knownChestIDs[id] then return true end
	if not name then return false end
	local n = name:lower()
	for _, w in ipairs(TREASURE_WORDS) do
		if n:find(w, 1, true) then return true end
	end
	return false
end

local function isKnown(k, id)
	for _, kn in pairs(known) do if kn[key(k, id)] then return true end end
	return false
end

local function isQuestSlot(slot)
	local _, _, _, _, _, _, isQuestItem, questID = GetLootSlotInfo(slot)
	if secret(isQuestItem) then return false end
	return isQuestItem or (questID and questID > 0) or false
end

local function saveLoot(k, id, slot)
	if isQuestSlot(slot) then return end -- quest items aren't real drops
	local link = GetLootSlotLink(slot)
	if not link or secret(link) then return end
	local itemID = tonumber(link:match("item:(%d+)"))
	if not itemID then return end
	local t = db.loot[key(k, id)] or {}
	db.loot[key(k, id)] = t
	if not t[itemID] then db.unshared = (db.unshared or 0) + 1 end
	t[itemID] = true
end

local function onLoot()
	if not db.record or (IsFishingLoot and IsFishingLoot()) then return end
	-- group loot slots by the object they came from
	local objects, order = {}, {}
	for i = 1, GetNumLootItems() do
		local kind, id = guidInfo((GetLootSourceInfo(i)))
		if kind == "GameObject" and id then
			local o = objects[id]
			if not o then o = { slots = {}, items = 0, quest = 0 }; objects[id] = o; order[#order + 1] = id end
			o.slots[#o.slots + 1] = i
			if GetLootSlotType(i) == (Enum.LootSlotType and Enum.LootSlotType.Item or 1) then
				o.items = o.items + 1
				if isQuestSlot(i) then o.quest = o.quest + 1 end
			end
		elseif (kind == "Creature" or kind == "Vehicle") and id and isKnown("rare", id) then
			saveLoot("rare", id, i)
		end
	end
	local recent = lastObjectTime and GetTime() - lastObjectTime < 15
	for _, id in ipairs(order) do
		local o = objects[id]
		local name = recent and lastObject or nil
		-- quest objects: everything inside is a quest item, or the object showed quest progress (x/y)
		local questObject = (o.items > 0 and o.quest == o.items) or (recent and lastObjectQuest)
		if not questObject and not isBookName(name) and looksLikeTreasure(id, name) then record("treasure", id, name or "Treasure") end
		if isKnown("treasure", id) then
			for _, i in ipairs(o.slots) do saveLoot("treasure", id, i) end
		end
	end
end

---------------------------------------------------------------------------
-- Export window: copy recorded pins to share with the addon author
---------------------------------------------------------------------------
local exportFrame
local function exportText()
	local out, n = { "# HandyNotes_RaresTreasuresForever export v1: type,mapID,x,y,id,level,elite,name" }, 0
	for mapID, nodes in pairs(db.rec) do
		for _, node in pairs(nodes) do
			for _, c in ipairs(node.pts) do
				local x, y = getXY(c)
				out[#out + 1] = ("%s,%d,%.2f,%.2f,%d,%s,%s,%s"):format(node.k == "rare" and "R" or "T", mapID,
					x * 100, y * 100, node.id, node.lv or "", node.el and 1 or 0, (node.n or ""):gsub(",", " "))
				n = n + 1
			end
		end
	end
	for k, items in pairs(db.loot) do
		local kind, id = k:match("^(%a+):(%d+)$")
		if kind then
			for itemID in pairs(items) do
				out[#out + 1] = ("L,%s,%s,%d"):format(kind, id, itemID)
				n = n + 1
			end
		end
	end
	return table.concat(out, "\n"), n
end

local function showExport()
	if not exportFrame then
		local f = CreateFrame("Frame", "RaresTreasuresForeverExport", UIParent, "BackdropTemplate")
		f:SetSize(560, 360); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG")
		f:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", edgeSize = 24, insets = { left = 6, right = 6, top = 6, bottom = 6 } })
		f:EnableMouse(true); f:SetMovable(true); f:RegisterForDrag("LeftButton")
		f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
		f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
		f.title:SetPoint("TOP", 0, -14)
		local close = CreateFrame("Button", nil, f, "UIPanelCloseButton"); close:SetPoint("TOPRIGHT", -4, -4)
		local sf = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
		sf:SetPoint("TOPLEFT", 16, -36); sf:SetPoint("BOTTOMRIGHT", -34, 16)
		local eb = CreateFrame("EditBox", nil, sf)
		eb:SetMultiLine(true); eb:SetFontObject(ChatFontNormal); eb:SetWidth(500); eb:SetAutoFocus(false)
		eb:SetScript("OnEscapePressed", function() f:Hide() end)
		sf:SetScrollChild(eb)
		f.eb = eb; exportFrame = f
	end
	local text, n = exportText()
	exportFrame.title:SetText(("Recorded pins and loot: %d  (Ctrl+A, Ctrl+C to copy)"):format(n))
	exportFrame.eb:SetText(text); exportFrame:Show()
	db.unshared = 0
	exportFrame.eb:SetFocus(); exportFrame.eb:HighlightText()
end

---------------------------------------------------------------------------
-- Share reminder: a chat message with a clickable link to the export window
---------------------------------------------------------------------------
local PREFIX = "|cffffd200Rares & Treasures Forever:|r "
local LINK_ID = "addon:RaresTreasuresForever:export"
local EXPORT_LINK = "|cff40ff40|H" .. LINK_ID .. "|h[Click here to open the export window]|h|r"
local REMIND_MIN_FINDS = 5          -- only nag when there's something worth sharing
local REMIND_EVERY = 60 * 60        -- at most once an hour

local lastClick = 0
local function onLinkClicked(link)
	if link ~= LINK_ID or GetTime() - lastClick < 0.5 then return end
	lastClick = GetTime()
	showExport()
end
-- modern clients route "addon:" links through EventRegistry; the hook is a fallback
if EventRegistry and EventRegistry.RegisterCallback then
	EventRegistry:RegisterCallback("SetItemRef", function(_, link) onLinkClicked(link) end)
end
if SetItemRef then hooksecurefunc("SetItemRef", function(link) onLinkClicked(link) end) end

local function remindToShare(force)
	if not db or (not force and not db.remind) then return end
	local n = db.unshared or 0
	if not force and (n < REMIND_MIN_FINDS or time() - (db.lastReminder or 0) < REMIND_EVERY) then return end
	db.lastReminder = time()
	DEFAULT_CHAT_FRAME:AddMessage(PREFIX .. ("You've found |cffffffff%d|r new rares, treasures or drops that aren't in the addon yet. Sharing them puts them on everyone's map, so please share regularly. "):format(n) .. EXPORT_LINK .. " |cff999999(or type /frares export)|r")
end

---------------------------------------------------------------------------
-- Options (/handynotes -> Plugins)
---------------------------------------------------------------------------
local function countRecorded()
	local n = 0
	for _, nodes in pairs(db.rec) do for _, node in pairs(nodes) do n = n + #node.pts end end
	return n
end

local options = {
	type = "group", name = "Rares and Treasures Forever",
	get = function(info) return db[info[#info]] end,
	set = function(info, v) db[info[#info]] = v; rebuild(); refresh() end,
	args = {
		desc = { type = "description", order = 0, name = "Rares and treasures in WoW Forever. Spawn data from the CMaNGOS project (GPL-3.0), checked against Forever, plus anything you record yourself. Pins marked \"unconfirmed\" come from classic data and haven't been checked in Forever yet." },
		showRares     = { type = "toggle", order = 1, name = "Show rares" },
		showTreasures = { type = "toggle", order = 2, name = "Show treasures" },
		showAlt       = { type = "toggle", order = 3, name = "Show alternate rare spawn points", width = "full" },
		showUnconfirmed = { type = "toggle", order = 3.5, name = "Show unconfirmed pins", desc = "Rares and treasures from classic data that haven't been checked in Forever yet.", width = "full" },
		minimap       = { type = "toggle", order = 4, name = "Show on minimap" },
		scaleRare     = { type = "range", order = 10, name = "Rare icon size", min = 0.3, max = 3, step = 0.05 },
		scaleTreasure = { type = "range", order = 11, name = "Treasure icon size", min = 0.3, max = 3, step = 0.05 },
		alpha         = { type = "range", order = 12, name = "Icon opacity", min = 0.1, max = 1, step = 0.05 },
		recorder = { type = "group", inline = true, order = 20, name = "Recorder", args = {
			record       = { type = "toggle", order = 1, name = "Record new rares and treasures", desc = "Saves a pin when you target, mouse over or see the nameplate of a rare, or loot a treasure, at a spot the addon doesn't know yet.", width = "full" },
			recordChat   = { type = "toggle", order = 2, name = "Chat message when something is recorded", width = "full" },
			remind       = { type = "toggle", order = 2.5, name = "Remind me to share my finds", desc = "At most once an hour, when you have 5 or more new finds, a chat message with a link to the export window.", width = "full" },
			showRecorded = { type = "toggle", order = 3, name = "Show my recorded pins", width = "full" },
			count        = { type = "description", order = 4, name = function() return "Recorded pins: " .. countRecorded() end },
			export       = { type = "execute", order = 5, name = "Export recorded pins", desc = "Opens a window with your recorded pins as text, to share with the addon author (also /frares export).", func = showExport },
			clear        = { type = "execute", order = 6, name = "Delete recorded pins", confirm = true, confirmText = "Delete all pins you recorded?",
				func = function() wipe(db.rec); rebuild(); refresh() end },
		} },
		lootGroup = { type = "group", inline = true, order = 15, name = "Loot in tooltip", args = {
			showLoot    = { type = "toggle", order = 1, name = "Show loot", width = "full" },
			lootQuality = { type = "select", order = 2, name = "Minimum quality",
				values = { [0] = "Poor", [1] = "Common", [2] = "Uncommon", [3] = "Rare", [4] = "Epic" } },
			maxLoot     = { type = "range", order = 3, name = "Max item lines", min = 1, max = 60, step = 1 },
			lootDesc    = { type = "description", order = 4, name = "Items you loot from rares and treasures are saved and marked \"seen in Forever\". The % values are classic drop chances and may differ in Forever." },
		} },
		unhide = { type = "execute", order = 30, name = "Unhide all hidden pins", func = function() wipe(db.hidden); refresh() end },
	},
}

---------------------------------------------------------------------------
-- Init and events
---------------------------------------------------------------------------
local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent", function(self, event, arg1)
	if event == "ADDON_LOADED" then
		if arg1 ~= ADDON then return end
		self:UnregisterEvent("ADDON_LOADED")
		HandyNotes_RaresTreasuresForeverDB = HandyNotes_RaresTreasuresForeverDB or {}
		db = HandyNotes_RaresTreasuresForeverDB
		for k, v in pairs(defaults) do
			if db[k] == nil then db[k] = (type(v) == "table") and {} or v end
		end
		removeRecordedBooks()
		rebuild()
		HandyNotes:RegisterPluginDB(PLUGIN, handler, options)
		self:RegisterEvent("PLAYER_TARGET_CHANGED")
		self:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
		self:RegisterEvent("NAME_PLATE_UNIT_ADDED")
		self:RegisterEvent("LOOT_OPENED")
		self:RegisterEvent("GET_ITEM_INFO_RECEIVED")
		self:RegisterEvent("PLAYER_ENTERING_WORLD")
		C_Timer.NewTicker(15 * 60, function() remindToShare() end)
	elseif event == "PLAYER_ENTERING_WORLD" then
		self:UnregisterEvent("PLAYER_ENTERING_WORLD")
		C_Timer.After(15, function() remindToShare() end)
	elseif event == "GET_ITEM_INFO_RECEIVED" then
		if tooltipPin and not self.pending then
			self.pending = true
			C_Timer.After(0.2, function()
				self.pending = false
				local t = tooltipPin
				if t and GameTooltip:GetOwner() == t[1] then handler.OnEnter(t[1], t[2], t[3]) end
			end)
		end
	elseif event == "PLAYER_TARGET_CHANGED" then
		checkUnit("target")
	elseif event == "UPDATE_MOUSEOVER_UNIT" then
		checkUnit("mouseover")
	elseif event == "NAME_PLATE_UNIT_ADDED" then
		checkUnit(arg1)
	elseif event == "LOOT_OPENED" then
		onLoot()
	end
end)

SLASH_FOREVERRARES1 = "/frares"
SlashCmdList.FOREVERRARES = function(msg)
	msg = (msg or ""):lower()
	if msg == "export" then return showExport() end
	if msg == "remind" then return remindToShare(true) end
	local n = 0
	for _, nodes in pairs(ns.points) do for _ in pairs(nodes) do n = n + 1 end end
	print(("|cffffd200Rares & Treasures Forever:|r %d built-in pins, %d recorded by you. |cffffffff/frares export|r to share them. Options: /handynotes > Plugins."):format(n, countRecorded()))
end
